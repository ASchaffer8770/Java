package com.alexschaffer.mvcdojoninjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NinjasDojosMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
