public class Item {

    //fields
    public String name;
    public double price;
}